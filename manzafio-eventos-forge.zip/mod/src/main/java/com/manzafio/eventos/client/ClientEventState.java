package com.manzafio.eventos.client;

import com.manzafio.eventos.event.EventPhase;
import com.manzafio.eventos.event.FxType;
import com.manzafio.eventos.event.SolarEventManager;
import com.manzafio.eventos.registry.ModSounds;
import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.level.Level;

/** Estado del evento visto desde el cliente + temporizadores de efectos. */
public final class ClientEventState {
    public static final int FLASH_TICKS = 200;   // 10 segundos ciego
    public static final int EXPLOSION_ANIM = 140;

    private static EventPhase phase = EventPhase.NONE;
    private static int ticksLeft;
    private static int totalTicks;

    // Temporizadores de efectos
    public static int flashTicks;
    public static int shakeTicks;
    public static int shakeMax = 1;
    public static float shakeStrength;
    public static int pulseTicks;
    public static final int PULSE_MAX = 30;
    public static int explosionAge = -1;
    public static int radiationHitTicks;
    public static int clearTicks;
    public static int clientTicks;

    private ClientEventState() {}

    public static EventPhase phase() { return phase; }
    public static int ticksLeft() { return ticksLeft; }
    public static int totalTicks() { return totalTicks; }

    /** 0 al iniciar la cuenta regresiva, 1 cuando explota. */
    public static float progress(float partialTick) {
        if (totalTicks <= 0) return 0;
        float left = Math.max(0, ticksLeft - partialTick);
        return Math.min(1F, Math.max(0F, 1F - left / totalTicks));
    }

    public static boolean inOverworld() {
        Minecraft mc = Minecraft.getInstance();
        return mc.level != null && mc.level.dimension() == Level.OVERWORLD;
    }

    public static boolean isPlayerSafe() {
        Minecraft mc = Minecraft.getInstance();
        return mc.player != null && mc.player.getBlockY() <= SolarEventManager.SAFE_Y;
    }

    public static void reset() {
        phase = EventPhase.NONE;
        ticksLeft = totalTicks = 0;
        flashTicks = shakeTicks = pulseTicks = radiationHitTicks = clearTicks = 0;
        explosionAge = -1;
    }

    public static void onSync(byte phaseId, int left, int total) {
        EventPhase newPhase = EventPhase.byId(phaseId);
        phase = newPhase;
        ticksLeft = left;
        totalTicks = total;
    }

    public static void onFx(byte type) {
        if (!inOverworld()) return;
        switch (type) {
            case FxType.START -> {
                explosionAge = -1;
                play(ModSounds.SIREN.get(), 1.0F, 0.8F);
                shake(30, 1.2F);
            }
            case FxType.HEAT_PULSE -> {
                pulseTicks = PULSE_MAX;
                float p = progress(0);
                shake(20, 0.8F + p * 2.5F);
                play(ModSounds.HEATWAVE.get(), 0.8F + p * 0.3F, 0.5F + p * 0.5F);
                ClientFx.spawnHeatWave(p);
            }
            case FxType.EXPLOSION -> {
                explosionAge = 0;
                flashTicks = FLASH_TICKS;
                shake(100, 9F);
                play(ModSounds.EXPLOSION.get(), 0.9F, 1.0F);
                play(SoundEvents.LIGHTNING_BOLT_THUNDER, 0.5F, 1.0F);
                play(SoundEvents.GENERIC_EXPLODE, 0.5F, 1.0F);
                play(ModSounds.TINNITUS.get(), 1.0F, 1.0F);
            }
            case FxType.CANCEL -> {
                play(SoundEvents.BEACON_DEACTIVATE, 1.0F, 1.0F);
                Minecraft.getInstance().getSoundManager().stop(ModSounds.SIREN.getId(), null);
                Minecraft.getInstance().getSoundManager().stop(ModSounds.TINNITUS.getId(), null);
                reset();
            }
            case FxType.RADIATION_HIT -> {
                radiationHitTicks = 40;
                shake(25, 2.5F);
                play(SoundEvents.FIRECHARGE_USE, 0.6F, 1.0F);
            }
            case FxType.ATMOSPHERE_CLEAR -> {
                clearTicks = 80;
                play(SoundEvents.BEACON_ACTIVATE, 1.2F, 1.0F);
                play(SoundEvents.AMETHYST_BLOCK_CHIME, 1.0F, 1.0F);
            }
            default -> {}
        }
    }

    public static void shake(int ticks, float strength) {
        if (strength >= shakeStrength * (shakeTicks / (float) Math.max(1, shakeMax))) {
            shakeTicks = ticks;
            shakeMax = ticks;
            shakeStrength = strength;
        }
    }

    public static void play(SoundEvent sound, float pitch, float volume) {
        Minecraft.getInstance().getSoundManager().play(SimpleSoundInstance.forUI(sound, pitch, volume));
    }

    public static void clientTick() {
        clientTicks++;
        int prevLeft = ticksLeft;
        if (phase != EventPhase.NONE && ticksLeft > 0) ticksLeft--;
        if (flashTicks > 0) flashTicks--;
        if (shakeTicks > 0) shakeTicks--;
        if (pulseTicks > 0) pulseTicks--;
        if (radiationHitTicks > 0) radiationHitTicks--;
        if (clearTicks > 0) clearTicks--;
        if (explosionAge >= 0) {
            explosionAge++;
            if (explosionAge > EXPLOSION_ANIM && phase != EventPhase.AFTERMATH) explosionAge = -1;
        }

        // Pitidos de los últimos 10 segundos
        if (phase == EventPhase.COUNTDOWN && inOverworld() && prevLeft / 20 != ticksLeft / 20) {
            int sec = ticksLeft / 20;
            if (sec < 10) {
                play(SoundEvents.NOTE_BLOCK_PLING.value(), 0.6F + (10 - sec) * 0.12F, 1.0F);
                shake(10, 1.0F + (10 - sec) * 0.35F);
            }
        }
    }
}
