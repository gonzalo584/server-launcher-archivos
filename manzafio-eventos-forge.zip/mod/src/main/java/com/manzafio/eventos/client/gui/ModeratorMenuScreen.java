package com.manzafio.eventos.client.gui;

import com.manzafio.eventos.client.ClientEventState;
import com.manzafio.eventos.event.EventPhase;
import com.manzafio.eventos.event.SolarEventManager;
import com.manzafio.eventos.network.CancelEventPacket;
import com.manzafio.eventos.network.ModNetwork;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;

/** Menú principal de moderadores (tecla H). */
public class ModeratorMenuScreen extends Screen {
    private static final int W = 270, H = 200;
    private int left, top;
    private final long openedAt = System.currentTimeMillis();
    private FancyButton cancelBtn;

    public ModeratorMenuScreen() {
        super(Component.literal("Panel de moderación"));
    }

    @Override
    protected void init() {
        left = (this.width - W) / 2;
        top = (this.height - H) / 2;
        int bw = W - 40;

        addRenderableWidget(new FancyButton(left + 20, top + 78, bw, 26,
                Component.literal("☀  EVENTOS"), 0xFFE0661A,
                () -> this.minecraft.setScreen(new EventsScreen(this))));

        cancelBtn = addRenderableWidget(new FancyButton(left + 20, top + 112, bw, 22,
                Component.literal("■  CANCELAR EVENTO ACTIVO"), 0xFFB0202A,
                () -> ModNetwork.toServer(new CancelEventPacket())));

        addRenderableWidget(new FancyButton(left + 20, top + H - 34, bw, 20,
                Component.literal("CERRAR"), 0xFF3A3A48, this::onClose));
    }

    @Override
    public void tick() {
        super.tick();
        cancelBtn.active = ClientEventState.phase() != EventPhase.NONE;
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        float openAnim = Math.min(1F, (System.currentTimeMillis() - openedAt) / 220F);
        float ease = 1F - (1F - openAnim) * (1F - openAnim);
        float time = ClientEventState.clientTicks + partialTick;

        this.renderBackground(g);
        g.fillGradient(0, 0, this.width, this.height, 0x60200808, 0xA0000000);

        g.pose().pushPose();
        float s = 0.9F + 0.1F * ease;
        g.pose().translate(this.width / 2F, this.height / 2F, 0);
        g.pose().scale(s, s, 1F);
        g.pose().translate(-this.width / 2F, -this.height / 2F, 0);

        UiDraw.panel(g, left, top, W, H, 0xFF5A1A, time);

        // Encabezado
        UiDraw.hGradient(g, left + 1, top + 1, left + W - 1, top + 44, 0xC0FF5A1A, 0x20FFC23A);
        for (int i = 0; i < 6; i++) {
            float sx = (time * (0.4F + i * 0.13F) + i * 47) % (W - 10);
            g.fill(left + 5 + (int) sx, top + 6 + i * 6, left + 7 + (int) sx, top + 7 + i * 6, 0x50FFFFFF);
        }
        UiDraw.sun(g, left + 26, top + 22, 11, time, 0.2F);
        g.drawString(this.font, "PANEL DE MODERACIÓN", left + 46, top + 12, 0xFFFFFFFF, true);
        g.drawString(this.font, "MANZAFIO", left + 46, top + 25, UiDraw.lerpColor(0.5F + 0.5F * Mth.sin(time * 0.1F), 0xFFFFC23A, 0xFFFF6A3A), true);

        // Estado
        String state;
        int stateColor;
        EventPhase phase = ClientEventState.phase();
        if (phase == EventPhase.COUNTDOWN) {
            state = "● Explosión Solar en curso — " + SolarEventManager.formatTime(ClientEventState.ticksLeft());
            stateColor = 0xFFFF7A3A;
        } else if (phase == EventPhase.AFTERMATH) {
            state = "● Radiación activa — " + SolarEventManager.formatTime(ClientEventState.ticksLeft());
            stateColor = 0xFFFFD02A;
        } else {
            state = "● Sin eventos activos";
            stateColor = 0xFF7CFF9A;
        }
        g.fill(left + 20, top + 52, left + W - 20, top + 68, 0x40000000);
        g.drawCenteredString(this.font, state, left + W / 2, top + 56, stateColor);

        super.render(g, mouseX, mouseY, partialTick);

        g.drawCenteredString(this.font, "Tecla H para abrir este panel", left + W / 2, top + H - 10, 0xFF6A6A6A);
        g.pose().popPose();
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
