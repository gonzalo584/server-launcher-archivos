package com.manzafio.eventos.registry;

import com.manzafio.eventos.ManzafioEventos;
import com.manzafio.eventos.event.HeatRadiationEffect;
import net.minecraft.world.effect.MobEffect;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModEffects {
    public static final DeferredRegister<MobEffect> EFFECTS =
            DeferredRegister.create(ForgeRegistries.MOB_EFFECTS, ManzafioEventos.MODID);

    public static final RegistryObject<MobEffect> HEAT_RADIATION =
            EFFECTS.register("heat_radiation", HeatRadiationEffect::new);

    private ModEffects() {}
}
