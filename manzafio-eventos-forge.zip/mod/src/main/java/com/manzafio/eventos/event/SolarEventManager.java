package com.manzafio.eventos.event;

import com.manzafio.eventos.network.FxPacket;
import com.manzafio.eventos.network.ModNetwork;
import com.manzafio.eventos.network.SyncEventPacket;
import com.manzafio.eventos.registry.ModDamage;
import com.manzafio.eventos.registry.ModEffects;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.level.Level;

/**
 * Lógica del evento "Explosión Solar" (lado servidor).
 *
 * 1) COUNTDOWN: el sol se calienta durante el tiempo elegido. Hay que bajar a Y <= -10.
 * 2) Al acabar el tiempo el sol explota: quien esté arriba de Y -10 muere calcinado.
 *    No se destruye ningún bloque.
 * 3) AFTERMATH (3 min): atmósfera radiactiva. Si subes arriba de Y -10 te da
 *    "Radiación de calor" durante 1 minuto, que te quita corazones hasta matarte.
 * 4) Todo vuelve a la normalidad.
 */
public final class SolarEventManager {
    public static final String EVENT_ID = "solar_explosion";
    public static final int SAFE_Y = -10;
    public static final int AFTERMATH_TICKS = 20 * 60 * 3;
    public static final int RADIATION_TICKS = 20 * 60;
    public static final int MIN_SECONDS = 10;
    public static final int MAX_SECONDS = 60 * 60;

    private static EventPhase phase = EventPhase.NONE;
    private static int ticksLeft;
    private static int totalTicks;
    private static int nextPulse;

    private SolarEventManager() {}

    public static EventPhase phase() { return phase; }
    public static boolean isActive() { return phase != EventPhase.NONE; }

    public static boolean start(MinecraftServer server, int seconds, String startedBy) {
        if (isActive()) return false;
        seconds = Mth.clamp(seconds, MIN_SECONDS, MAX_SECONDS);
        phase = EventPhase.COUNTDOWN;
        totalTicks = seconds * 20;
        ticksLeft = totalTicks;
        nextPulse = 80;

        ServerLevel overworld = server.overworld();
        overworld.setDayTime(6000L); // mediodía: el sol queda justo arriba
        overworld.setWeatherParameters(totalTicks + AFTERMATH_TICKS + 200, 0, false, false);

        broadcast(server, Component.literal("☀ ").withStyle(ChatFormatting.GOLD)
                .append(Component.literal("EXPLOSIÓN SOLAR").withStyle(ChatFormatting.RED, ChatFormatting.BOLD))
                .append(Component.literal(" — el sol va a explotar en " + formatTime(totalTicks)
                        + ". ¡Bajen a la capa Y " + SAFE_Y + " o más abajo!").withStyle(ChatFormatting.YELLOW)));
        if (startedBy != null) {
            broadcast(server, Component.literal("Evento iniciado por " + startedBy).withStyle(ChatFormatting.DARK_GRAY));
        }

        fx(FxType.START);
        sync(server);
        return true;
    }

    public static boolean cancel(MinecraftServer server, String cancelledBy) {
        if (!isActive()) return false;
        phase = EventPhase.NONE;
        ticksLeft = 0;
        totalTicks = 0;
        for (ServerPlayer p : server.getPlayerList().getPlayers()) {
            p.removeEffect(ModEffects.HEAT_RADIATION.get());
        }
        broadcast(server, Component.literal("✖ El evento fue cancelado"
                + (cancelledBy != null ? " por " + cancelledBy : "") + ". Todo vuelve a la normalidad.")
                .withStyle(ChatFormatting.GRAY));
        fx(FxType.CANCEL);
        sync(server);
        return true;
    }

    public static void reset() {
        phase = EventPhase.NONE;
        ticksLeft = 0;
        totalTicks = 0;
    }

    public static void tick(MinecraftServer server) {
        if (phase == EventPhase.NONE) return;
        ticksLeft--;

        if (ticksLeft % 20 == 0) {
            server.overworld().setDayTime(6000L);
        }

        if (phase == EventPhase.COUNTDOWN) {
            float progress = 1.0F - ticksLeft / (float) totalTicks;
            if (--nextPulse <= 0) {
                fx(FxType.HEAT_PULSE);
                nextPulse = (int) Mth.lerp(progress, 220, 35);
            }
            int secLeft = ticksLeft / 20;
            if (ticksLeft % 20 == 0 && (secLeft == 60 || secLeft == 30)) {
                broadcast(server, Component.literal("⚠ Faltan " + secLeft + " segundos para la explosión solar. ¡A la capa Y "
                        + SAFE_Y + "!").withStyle(ChatFormatting.RED));
            }
            if (ticksLeft <= 0) {
                explode(server);
                return;
            }
        } else if (phase == EventPhase.AFTERMATH) {
            if (ticksLeft % 20 == 0) radiationCheck(server);
            if (ticksLeft <= 0) {
                finish(server);
                return;
            }
        }

        if (ticksLeft % 20 == 0) sync(server);
    }

    private static void explode(MinecraftServer server) {
        phase = EventPhase.AFTERMATH;
        totalTicks = AFTERMATH_TICKS;
        ticksLeft = totalTicks;

        fx(FxType.EXPLOSION);
        sync(server);

        for (ServerPlayer p : server.getPlayerList().getPlayers()) {
            if (!affects(p)) continue;
            if (p.getBlockY() > SAFE_Y) {
                p.setSecondsOnFire(8);
                p.invulnerableTime = 0;
                p.hurt(ModDamage.source(p.level(), ModDamage.SOLAR_FLARE), 10000.0F);
            }
        }

        broadcast(server, Component.literal("☀ ¡EL SOL EXPLOTÓ! ").withStyle(ChatFormatting.RED, ChatFormatting.BOLD)
                .append(Component.literal("La atmósfera está radiactiva. No salgan arriba de Y " + SAFE_Y
                        + " en 3 minutos.").withStyle(ChatFormatting.GOLD)));
    }

    private static void radiationCheck(MinecraftServer server) {
        for (ServerPlayer p : server.getPlayerList().getPlayers()) {
            if (!affects(p)) continue;
            if (p.getBlockY() > SAFE_Y && !p.hasEffect(ModEffects.HEAT_RADIATION.get())) {
                p.addEffect(new MobEffectInstance(ModEffects.HEAT_RADIATION.get(), RADIATION_TICKS, 0, false, true, true));
                p.sendSystemMessage(Component.literal("☢ ¡Saliste antes de tiempo! Tienes radiación de calor.")
                        .withStyle(ChatFormatting.RED, ChatFormatting.BOLD));
                ModNetwork.toPlayer(p, new FxPacket(FxType.RADIATION_HIT));
            }
        }
    }

    private static void finish(MinecraftServer server) {
        phase = EventPhase.NONE;
        ticksLeft = 0;
        totalTicks = 0;
        broadcast(server, Component.literal("✔ La atmósfera se estabilizó. Ya pueden salir.")
                .withStyle(ChatFormatting.GREEN));
        fx(FxType.ATMOSPHERE_CLEAR);
        sync(server);
    }

    /** Solo afecta a jugadores vivos en supervivencia/aventura dentro del Overworld. */
    private static boolean affects(ServerPlayer p) {
        return p.isAlive() && !p.isCreative() && !p.isSpectator() && p.level().dimension() == Level.OVERWORLD;
    }

    public static SyncEventPacket syncPacket() {
        return new SyncEventPacket((byte) phase.ordinal(), Math.max(0, ticksLeft), totalTicks);
    }

    public static void sync(MinecraftServer server) {
        ModNetwork.toAll(syncPacket());
    }

    public static void syncTo(ServerPlayer player) {
        ModNetwork.toPlayer(player, syncPacket());
    }

    private static void fx(byte type) {
        ModNetwork.toAll(new FxPacket(type));
    }

    private static void broadcast(MinecraftServer server, Component msg) {
        server.getPlayerList().broadcastSystemMessage(msg, false);
    }

    public static String formatTime(int ticks) {
        int s = Math.max(0, (ticks + 19) / 20);
        return String.format("%d:%02d", s / 60, s % 60);
    }
}
