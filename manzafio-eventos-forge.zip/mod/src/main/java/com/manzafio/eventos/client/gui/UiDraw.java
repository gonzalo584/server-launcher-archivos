package com.manzafio.eventos.client.gui;

import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;

/** Utilidades de dibujo para la interfaz. */
public final class UiDraw {
    private UiDraw() {}

    public static int argb(int a, int r, int g, int b) {
        return (Mth.clamp(a, 0, 255) << 24) | (Mth.clamp(r, 0, 255) << 16) | (Mth.clamp(g, 0, 255) << 8) | Mth.clamp(b, 0, 255);
    }

    public static int withAlpha(int rgb, float alpha) {
        return ((int) (Mth.clamp(alpha, 0F, 1F) * 255) << 24) | (rgb & 0xFFFFFF);
    }

    public static int lerpColor(float t, int c1, int c2) {
        t = Mth.clamp(t, 0F, 1F);
        int a = (int) Mth.lerp(t, (c1 >>> 24) & 255, (c2 >>> 24) & 255);
        int r = (int) Mth.lerp(t, (c1 >> 16) & 255, (c2 >> 16) & 255);
        int g = (int) Mth.lerp(t, (c1 >> 8) & 255, (c2 >> 8) & 255);
        int b = (int) Mth.lerp(t, c1 & 255, c2 & 255);
        return argb(a, r, g, b);
    }

    /** Degradado horizontal (de izquierda a derecha) usando franjas. */
    public static void hGradient(GuiGraphics g, int x1, int y1, int x2, int y2, int left, int right) {
        int w = x2 - x1;
        if (w <= 0) return;
        int steps = Math.min(w, 48);
        for (int i = 0; i < steps; i++) {
            int a = x1 + w * i / steps;
            int b = x1 + w * (i + 1) / steps;
            g.fill(a, y1, b, y2, lerpColor((i + 0.5F) / steps, left, right));
        }
    }

    /** Viñeta de color en los bordes de la pantalla. */
    public static void vignette(GuiGraphics g, int w, int h, int rgb, float alpha, int thickness) {
        if (alpha <= 0.01F) return;
        int edge = withAlpha(rgb, alpha);
        int clear = withAlpha(rgb, 0F);
        g.fillGradient(0, 0, w, thickness, edge, clear);
        g.fillGradient(0, h - thickness, w, h, clear, edge);
        hGradient(g, 0, 0, thickness, h, edge, clear);
        hGradient(g, w - thickness, 0, w, h, clear, edge);
    }

    /** Círculo relleno. */
    public static void circle(GuiGraphics g, int cx, int cy, int r, int color) {
        for (int dy = -r; dy <= r; dy++) {
            int half = (int) Math.sqrt(r * r - dy * dy);
            g.fill(cx - half, cy + dy, cx + half + 1, cy + dy + 1, color);
        }
    }

    /** Sol animado (para iconos del menú). */
    public static void sun(GuiGraphics g, int cx, int cy, int r, float time, float heat) {
        float pulse = 1F + 0.08F * Mth.sin(time * 0.15F);
        int rr = (int) (r * pulse);
        circle(g, cx, cy, rr + 6, withAlpha(0xFF5A10, 0.12F));
        circle(g, cx, cy, rr + 3, withAlpha(0xFF7A20, 0.25F));
        circle(g, cx, cy, rr, lerpColor(heat, 0xFFFFC23A, 0xFFE02A10));
        circle(g, cx, cy, (int) (rr * 0.65F), lerpColor(heat, 0xFFFFE89A, 0xFFFF7A2A));
        circle(g, cx - rr / 3, cy - rr / 3, Math.max(1, rr / 5), withAlpha(0xFFFFFF, 0.55F));
    }

    /** Marco con borde degradado y fondo oscuro. */
    public static void panel(GuiGraphics g, int x, int y, int w, int h, int accent, float time) {
        // sombra
        g.fill(x + 4, y + 4, x + w + 4, y + h + 4, 0x66000000);
        // borde
        float glow = 0.6F + 0.4F * Mth.sin(time * 0.08F);
        int c1 = withAlpha(accent, 0.6F + 0.4F * glow);
        int c2 = withAlpha(0xFFD34D, 0.7F);
        hGradient(g, x - 1, y - 1, x + w + 1, y + 1, c1, c2);
        hGradient(g, x - 1, y + h - 1, x + w + 1, y + h + 1, c2, c1);
        g.fillGradient(x - 1, y, x + 1, y + h, c1, c2);
        g.fillGradient(x + w - 1, y, x + w + 1, y + h, c2, c1);
        // fondo
        g.fillGradient(x + 1, y + 1, x + w - 1, y + h - 1, 0xF0140C10, 0xF00A0608);
    }

    public static void scaledCentered(GuiGraphics g, Font font, Component text, int cx, int y, float scale, int color) {
        g.pose().pushPose();
        g.pose().translate(cx, y, 0);
        g.pose().scale(scale, scale, 1F);
        g.drawString(font, text, -font.width(text) / 2, 0, color, true);
        g.pose().popPose();
    }

    public static void scaledCentered(GuiGraphics g, Font font, String text, int cx, int y, float scale, int color) {
        scaledCentered(g, font, Component.literal(text), cx, y, scale, color);
    }
}
