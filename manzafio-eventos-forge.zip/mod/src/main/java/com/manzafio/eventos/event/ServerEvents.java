package com.manzafio.eventos.event;

import com.manzafio.eventos.ManzafioEventos;
import com.mojang.brigadier.arguments.DoubleArgumentType;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.server.ServerStoppedEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.server.ServerLifecycleHooks;

@Mod.EventBusSubscriber(modid = ManzafioEventos.MODID)
public final class ServerEvents {

    @SubscribeEvent
    public static void onServerTick(TickEvent.ServerTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        MinecraftServer server = ServerLifecycleHooks.getCurrentServer();
        if (server != null) SolarEventManager.tick(server);
    }

    @SubscribeEvent
    public static void onLogin(PlayerEvent.PlayerLoggedInEvent event) {
        if (event.getEntity() instanceof ServerPlayer sp) {
            SolarEventManager.syncTo(sp);
        }
    }

    @SubscribeEvent
    public static void onServerStopped(ServerStoppedEvent event) {
        SolarEventManager.reset();
    }

    /** Comandos de respaldo: /manzafio explosionsolar <minutos>  y  /manzafio cancelar */
    @SubscribeEvent
    public static void onRegisterCommands(RegisterCommandsEvent event) {
        event.getDispatcher().register(Commands.literal("manzafio")
                .requires(src -> src.hasPermission(2))
                .then(Commands.literal("explosionsolar")
                        .then(Commands.argument("minutos", DoubleArgumentType.doubleArg(0.17, 60))
                                .executes(ctx -> {
                                    CommandSourceStack src = ctx.getSource();
                                    int seconds = (int) Math.round(DoubleArgumentType.getDouble(ctx, "minutos") * 60.0);
                                    if (!SolarEventManager.start(src.getServer(), seconds, src.getTextName())) {
                                        src.sendFailure(Component.literal("Ya hay un evento activo. Cancélalo primero."));
                                        return 0;
                                    }
                                    return 1;
                                })))
                .then(Commands.literal("cancelar")
                        .executes(ctx -> {
                            CommandSourceStack src = ctx.getSource();
                            if (!SolarEventManager.cancel(src.getServer(), src.getTextName())) {
                                src.sendFailure(Component.literal("No hay ningún evento activo."));
                                return 0;
                            }
                            return 1;
                        })));
    }

    private ServerEvents() {}
}
