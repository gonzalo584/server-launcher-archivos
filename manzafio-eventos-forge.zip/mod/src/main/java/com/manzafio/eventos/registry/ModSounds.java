package com.manzafio.eventos.registry;

import com.manzafio.eventos.ManzafioEventos;
import net.minecraft.sounds.SoundEvent;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModSounds {
    public static final DeferredRegister<SoundEvent> SOUNDS =
            DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, ManzafioEventos.MODID);

    public static final RegistryObject<SoundEvent> TINNITUS = reg("tinnitus");
    public static final RegistryObject<SoundEvent> EXPLOSION = reg("explosion");
    public static final RegistryObject<SoundEvent> HEATWAVE = reg("heatwave");
    public static final RegistryObject<SoundEvent> SIREN = reg("siren");
    public static final RegistryObject<SoundEvent> UI_CLICK = reg("ui_click");

    private static RegistryObject<SoundEvent> reg(String name) {
        return SOUNDS.register(name, () -> SoundEvent.createVariableRangeEvent(ManzafioEventos.id(name)));
    }

    private ModSounds() {}
}
