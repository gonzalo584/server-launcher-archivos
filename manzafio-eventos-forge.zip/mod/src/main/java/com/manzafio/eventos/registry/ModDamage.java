package com.manzafio.eventos.registry;

import com.manzafio.eventos.ManzafioEventos;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageType;
import net.minecraft.world.level.Level;

/** Tipos de daño definidos en data/manzafioeventos/damage_type/*.json */
public final class ModDamage {
    public static final ResourceKey<DamageType> SOLAR_FLARE =
            ResourceKey.create(Registries.DAMAGE_TYPE, ManzafioEventos.id("solar_flare"));
    public static final ResourceKey<DamageType> HEAT_RADIATION =
            ResourceKey.create(Registries.DAMAGE_TYPE, ManzafioEventos.id("heat_radiation"));

    public static DamageSource source(Level level, ResourceKey<DamageType> key) {
        return new DamageSource(level.registryAccess().registryOrThrow(Registries.DAMAGE_TYPE).getHolderOrThrow(key));
    }

    private ModDamage() {}
}
