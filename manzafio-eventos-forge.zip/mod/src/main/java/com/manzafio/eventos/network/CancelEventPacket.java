package com.manzafio.eventos.network;

import com.manzafio.eventos.event.SolarEventManager;
import net.minecraft.ChatFormatting;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Cliente -> servidor: "cancela el evento activo". */
public record CancelEventPacket() {

    public void encode(FriendlyByteBuf buf) {}

    public static CancelEventPacket decode(FriendlyByteBuf buf) {
        return new CancelEventPacket();
    }

    public static void handle(CancelEventPacket msg, Supplier<NetworkEvent.Context> ctx) {
        ServerPlayer player = ctx.get().getSender();
        if (player == null) return;
        if (!player.hasPermissions(2)) {
            player.sendSystemMessage(Component.literal("Solo los moderadores pueden cancelar eventos.").withStyle(ChatFormatting.RED));
            return;
        }
        if (!SolarEventManager.cancel(player.server, player.getGameProfile().getName())) {
            player.sendSystemMessage(Component.literal("No hay ningún evento activo.").withStyle(ChatFormatting.GRAY));
        }
    }
}
