package com.manzafio.eventos.client;

import com.manzafio.eventos.event.EventPhase;
import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.BufferUploader;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.Tesselator;
import com.mojang.blaze3d.vertex.VertexFormat;
import com.mojang.math.Axis;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.util.Mth;
import org.joml.Matrix4f;

/**
 * Dibuja el cielo del evento justo después del cielo vanilla (antes del terreno):
 * - Tinte rojo que crece con el tiempo
 * - Un sol gigante que palpita y crece
 * - La explosión (destello blanco + onda expansiva)
 * - Cielo rojo-amarillento tras la explosión
 */
public final class SkyRenderer {
    private static final float R = 60F;

    private SkyRenderer() {}

    public static void render(PoseStack poseStack, float partialTick) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || !ClientEventState.inOverworld()) return;

        EventPhase phase = ClientEventState.phase();
        int age = ClientEventState.explosionAge;
        boolean exploding = age >= 0 && age < ClientEventState.EXPLOSION_ANIM;
        if (phase == EventPhase.NONE && !exploding) return;

        float time = ClientEventState.clientTicks + partialTick;

        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.depthMask(false);
        RenderSystem.disableDepthTest();
        RenderSystem.disableCull();
        RenderSystem.setShader(GameRenderer::getPositionColorShader);
        RenderSystem.setShaderColor(1F, 1F, 1F, 1F);

        if (phase == EventPhase.COUNTDOWN) {
            float p = ClientEventState.progress(partialTick);
            float a = (float) Math.pow(p, 1.2) * 0.78F;
            // cenit rojo intenso, horizonte naranja
            tintDome(poseStack, 1.0F, 0.12F, 0.04F, a, 1.0F, 0.42F, 0.08F, a * 0.9F);
            drawDyingSun(poseStack, partialTick, p, time);
        } else if (phase == EventPhase.AFTERMATH) {
            float fadeIn = exploding ? Mth.clamp((age + partialTick) / 60F, 0F, 1F) : 1F;
            float wobble = 0.04F * Mth.sin(time * 0.05F);
            float a = (0.62F + wobble) * fadeIn;
            tintDome(poseStack, 1.0F, 0.62F, 0.18F, a, 1.0F, 0.82F, 0.35F, a * 1.05F);
            hideSun(poseStack, partialTick, 1.0F, 0.66F, 0.22F, 0.95F * fadeIn);
        }

        if (exploding) {
            drawExplosion(poseStack, partialTick, age + partialTick);
        }

        RenderSystem.defaultBlendFunc();
        RenderSystem.disableBlend();
        RenderSystem.enableCull();
        RenderSystem.enableDepthTest();
        RenderSystem.depthMask(true);
        RenderSystem.setShaderColor(1F, 1F, 1F, 1F);
    }

    // ---------------------------------------------------------------- cúpula de color

    private static void tintDome(PoseStack ps, float tr, float tg, float tb, float ta,
                                 float hr, float hg, float hb, float ha) {
        if (ta <= 0.001F && ha <= 0.001F) return;
        Matrix4f m = ps.last().pose();
        BufferBuilder bb = Tesselator.getInstance().getBuilder();
        bb.begin(VertexFormat.Mode.QUADS, DefaultVertexFormat.POSITION_COLOR);

        // Techo
        bb.vertex(m, -R, R, -R).color(tr, tg, tb, ta).endVertex();
        bb.vertex(m, -R, R, R).color(tr, tg, tb, ta).endVertex();
        bb.vertex(m, R, R, R).color(tr, tg, tb, ta).endVertex();
        bb.vertex(m, R, R, -R).color(tr, tg, tb, ta).endVertex();

        float[][] sides = {{-R, -R, R, -R}, {R, -R, R, R}, {R, R, -R, R}, {-R, R, -R, -R}};
        for (float[] s : sides) {
            // arriba: del color del cenit al del horizonte
            bb.vertex(m, s[0], R, s[1]).color(tr, tg, tb, ta).endVertex();
            bb.vertex(m, s[2], R, s[3]).color(tr, tg, tb, ta).endVertex();
            bb.vertex(m, s[2], 0, s[3]).color(hr, hg, hb, ha).endVertex();
            bb.vertex(m, s[0], 0, s[1]).color(hr, hg, hb, ha).endVertex();
            // abajo del horizonte
            bb.vertex(m, s[0], 0, s[1]).color(hr, hg, hb, ha).endVertex();
            bb.vertex(m, s[2], 0, s[3]).color(hr, hg, hb, ha).endVertex();
            bb.vertex(m, s[2], -R, s[3]).color(hr * 0.7F, hg * 0.7F, hb * 0.7F, ha).endVertex();
            bb.vertex(m, s[0], -R, s[1]).color(hr * 0.7F, hg * 0.7F, hb * 0.7F, ha).endVertex();
        }
        // Piso
        bb.vertex(m, -R, -R, -R).color(hr * 0.7F, hg * 0.7F, hb * 0.7F, ha).endVertex();
        bb.vertex(m, R, -R, -R).color(hr * 0.7F, hg * 0.7F, hb * 0.7F, ha).endVertex();
        bb.vertex(m, R, -R, R).color(hr * 0.7F, hg * 0.7F, hb * 0.7F, ha).endVertex();
        bb.vertex(m, -R, -R, R).color(hr * 0.7F, hg * 0.7F, hb * 0.7F, ha).endVertex();

        BufferUploader.drawWithShader(bb.end());
    }

    // ---------------------------------------------------------------- sol

    private static void pushSunSpace(PoseStack ps, float partialTick) {
        Minecraft mc = Minecraft.getInstance();
        ps.pushPose();
        ps.mulPose(Axis.YP.rotationDegrees(-90.0F));
        ps.mulPose(Axis.XP.rotationDegrees(mc.level.getTimeOfDay(partialTick) * 360.0F));
    }

    private static void drawDyingSun(PoseStack ps, float partialTick, float p, float time) {
        pushSunSpace(ps, partialTick);
        Matrix4f m = ps.last().pose();

        float speed = 0.15F + p * 0.9F;
        float pulse = 1F + (0.05F + p * 0.1F) * Mth.sin(time * speed);
        float flicker = p > 0.9F ? (Mth.sin(time * 2.7F) > 0 ? 1.0F : 0.55F) : 1F;

        float core = (16F + p * 34F) * pulse;
        float corona = (34F + p * 120F) * pulse;

        RenderSystem.blendFunc(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE);
        // Corona (brillo aditivo)
        disc(m, 100F, corona, 48, 1.0F, 0.45F - p * 0.2F, 0.1F, (0.35F + p * 0.45F) * flicker, 1.0F, 0.2F, 0.0F, 0F);
        // Destellos/rayos rotando
        rays(m, 100F, core * 1.1F, corona * 1.15F, 12, time * 0.01F * (1 + p * 4), (0.25F + p * 0.4F) * flicker);

        RenderSystem.defaultBlendFunc();
        // Núcleo: amarillo -> rojo sangre
        float cg = Mth.lerp(p, 0.92F, 0.25F);
        float cb = Mth.lerp(p, 0.55F, 0.05F);
        disc(m, 100F, core, 48, 1.0F, Math.min(1F, cg + 0.15F), Math.min(1F, cb + 0.2F), 1.0F, 1.0F, cg * 0.7F, cb * 0.5F, 1.0F);
        // Manchas oscuras que aparecen al final
        if (p > 0.5F) {
            float sa = (p - 0.5F) * 1.2F;
            for (int i = 0; i < 4; i++) {
                float ang = time * 0.004F + i * 1.7F;
                float d = core * 0.45F;
                Matrix4f mm = new Matrix4f(m).translate(Mth.cos(ang) * d, 0, Mth.sin(ang) * d);
                disc(mm, 100.01F, core * (0.12F + 0.04F * i), 16, 0.35F, 0.02F, 0.0F, sa, 0.5F, 0.05F, 0.0F, 0F);
            }
        }
        // Brillo blanco al final (a punto de explotar)
        if (p > 0.85F) {
            RenderSystem.blendFunc(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE);
            float w = (p - 0.85F) / 0.15F;
            disc(m, 100.02F, core * 0.8F, 32, 1F, 1F, 0.9F, w * flicker, 1F, 0.8F, 0.5F, 0F);
            RenderSystem.defaultBlendFunc();
        }
        ps.popPose();
    }

    private static void hideSun(PoseStack ps, float partialTick, float r, float g, float b, float a) {
        pushSunSpace(ps, partialTick);
        Matrix4f m = ps.last().pose();
        disc(m, 100F, 34F, 32, r, g, b, a, r, g, b, a * 0.8F);
        disc(m, 100F, 50F, 32, r, g, b, a * 0.6F, r, g, b, 0F);
        ps.popPose();
    }

    private static void drawExplosion(PoseStack ps, float partialTick, float age) {
        float t = Mth.clamp(age / ClientEventState.EXPLOSION_ANIM, 0F, 1F);
        float ease = 1F - (1F - t) * (1F - t) * (1F - t);
        pushSunSpace(ps, partialTick);
        Matrix4f m = ps.last().pose();

        RenderSystem.blendFunc(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE);
        // Bola de fuego que cubre el cielo
        float fire = 40F + ease * 450F;
        disc(m, 100F, fire, 64, 1F, 1F, 0.95F, (1F - t), 1F, 0.55F, 0.1F, (1F - t) * 0.6F);
        // Onda expansiva (anillo)
        float rin = 20F + age * 7F;
        ring(m, 100F, rin, rin + 30F + age * 0.6F, 64, 1F, 0.9F, 0.6F, Math.max(0F, 1F - t * 1.2F));
        float rin2 = 10F + age * 4F;
        ring(m, 100F, rin2, rin2 + 14F, 64, 1F, 0.5F, 0.15F, Math.max(0F, 0.8F - t));
        RenderSystem.defaultBlendFunc();

        ps.popPose();

        // Destello que tapa todo el cielo al principio
        if (age < 40) {
            float a = 1F - age / 40F;
            tintDome(ps, 1F, 1F, 1F, a, 1F, 0.95F, 0.85F, a);
        }
    }

    // ---------------------------------------------------------------- primitivas

    private static void disc(Matrix4f m, float y, float radius, int seg,
                             float cr, float cg, float cb, float ca,
                             float er, float eg, float eb, float ea) {
        BufferBuilder bb = Tesselator.getInstance().getBuilder();
        bb.begin(VertexFormat.Mode.TRIANGLE_FAN, DefaultVertexFormat.POSITION_COLOR);
        bb.vertex(m, 0, y, 0).color(cr, cg, cb, ca).endVertex();
        for (int i = 0; i <= seg; i++) {
            float a = (float) (i * Math.PI * 2.0 / seg);
            bb.vertex(m, Mth.cos(a) * radius, y, Mth.sin(a) * radius).color(er, eg, eb, ea).endVertex();
        }
        BufferUploader.drawWithShader(bb.end());
    }

    private static void ring(Matrix4f m, float y, float inner, float outer, int seg,
                             float r, float g, float b, float a) {
        if (a <= 0F) return;
        BufferBuilder bb = Tesselator.getInstance().getBuilder();
        bb.begin(VertexFormat.Mode.TRIANGLE_STRIP, DefaultVertexFormat.POSITION_COLOR);
        for (int i = 0; i <= seg; i++) {
            float ang = (float) (i * Math.PI * 2.0 / seg);
            float c = Mth.cos(ang), s = Mth.sin(ang);
            bb.vertex(m, c * inner, y, s * inner).color(r, g, b, 0F).endVertex();
            bb.vertex(m, c * outer, y, s * outer).color(r, g, b, a).endVertex();
        }
        BufferUploader.drawWithShader(bb.end());
    }

    private static void rays(Matrix4f m, float y, float inner, float outer, int count, float rot, float a) {
        BufferBuilder bb = Tesselator.getInstance().getBuilder();
        bb.begin(VertexFormat.Mode.TRIANGLES, DefaultVertexFormat.POSITION_COLOR);
        for (int i = 0; i < count; i++) {
            float ang = rot + (float) (i * Math.PI * 2.0 / count);
            float len = outer * (0.75F + 0.25F * Mth.sin(i * 2.3F + rot * 20F));
            float w = 0.09F;
            bb.vertex(m, Mth.cos(ang - w) * inner, y, Mth.sin(ang - w) * inner).color(1F, 0.6F, 0.2F, a).endVertex();
            bb.vertex(m, Mth.cos(ang + w) * inner, y, Mth.sin(ang + w) * inner).color(1F, 0.6F, 0.2F, a).endVertex();
            bb.vertex(m, Mth.cos(ang) * len, y, Mth.sin(ang) * len).color(1F, 0.3F, 0.05F, 0F).endVertex();
        }
        BufferUploader.drawWithShader(bb.end());
    }
}
