package com.manzafio.eventos.network;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Servidor -> cliente: estado actual del evento. */
public record SyncEventPacket(byte phase, int ticksLeft, int totalTicks) {

    public void encode(FriendlyByteBuf buf) {
        buf.writeByte(phase);
        buf.writeVarInt(ticksLeft);
        buf.writeVarInt(totalTicks);
    }

    public static SyncEventPacket decode(FriendlyByteBuf buf) {
        return new SyncEventPacket(buf.readByte(), buf.readVarInt(), buf.readVarInt());
    }

    public static void handle(SyncEventPacket msg, Supplier<NetworkEvent.Context> ctx) {
        DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () ->
                com.manzafio.eventos.client.ClientEventState.onSync(msg.phase(), msg.ticksLeft(), msg.totalTicks()));
    }
}
