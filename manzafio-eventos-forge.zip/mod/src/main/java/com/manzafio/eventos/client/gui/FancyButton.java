package com.manzafio.eventos.client.gui;

import com.manzafio.eventos.client.ClientEventState;
import com.manzafio.eventos.registry.ModSounds;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.AbstractButton;
import net.minecraft.client.gui.narration.NarrationElementOutput;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.client.sounds.SoundManager;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;

/** Botón con degradado, brillo al pasar el mouse y animación de "hover". */
public class FancyButton extends AbstractButton {
    private final int color;
    private final Runnable action;
    private float hoverAnim;

    public FancyButton(int x, int y, int w, int h, Component message, int color, Runnable action) {
        super(x, y, w, h, message);
        this.color = color;
        this.action = action;
    }

    @Override
    public void onPress() {
        action.run();
    }

    @Override
    public void playDownSound(SoundManager manager) {
        manager.play(SimpleSoundInstance.forUI(ModSounds.UI_CLICK.get(), 1.0F, 0.6F));
    }

    @Override
    public void renderWidget(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        boolean hover = this.active && this.isHoveredOrFocused();
        hoverAnim = Mth.clamp(hoverAnim + (hover ? 0.2F : -0.2F), 0F, 1F);

        int x = getX(), y = getY(), w = this.width, h = this.height;
        int base = this.active ? color : 0xFF3A3A3A;
        int top = UiDraw.lerpColor(hoverAnim * 0.45F, base | 0xFF000000, 0xFFFFFFFF);
        int bottom = UiDraw.lerpColor(0.45F, base | 0xFF000000, 0xFF000000);

        // brillo exterior al pasar el mouse
        if (hoverAnim > 0) {
            float t = ClientEventState.clientTicks + partialTick;
            float glow = hoverAnim * (0.35F + 0.15F * Mth.sin(t * 0.25F));
            g.fill(x - 3, y - 3, x + w + 3, y + h + 3, UiDraw.withAlpha(color, glow * 0.5F));
        }
        g.fill(x - 1, y - 1, x + w + 1, y + h + 1, hover ? 0xFFFFFFFF : 0xFF000000);
        g.fillGradient(x, y, x + w, y + h, top, bottom);
        g.fill(x, y, x + w, y + 1, 0x55FFFFFF);
        g.fill(x, y + h - 2, x + w, y + h, 0x40000000);

        int textColor = this.active ? 0xFFFFFFFF : 0xFF8A8A8A;
        int offset = hover ? (int) (hoverAnim * 2) : 0;
        g.drawCenteredString(Minecraft.getInstance().font, getMessage(), x + w / 2 + offset, y + (h - 8) / 2, textColor);
    }

    @Override
    protected void updateWidgetNarration(NarrationElementOutput output) {
        this.defaultButtonNarrationText(output);
    }
}
