package com.manzafio.eventos.event;

public enum EventPhase {
    /** Sin evento. */
    NONE,
    /** El sol se va calentando: cuenta regresiva para bajar a la capa segura. */
    COUNTDOWN,
    /** El sol ya explotó: atmósfera radiactiva durante 3 minutos. */
    AFTERMATH;

    public static EventPhase byId(int id) {
        EventPhase[] v = values();
        return id >= 0 && id < v.length ? v[id] : NONE;
    }
}
