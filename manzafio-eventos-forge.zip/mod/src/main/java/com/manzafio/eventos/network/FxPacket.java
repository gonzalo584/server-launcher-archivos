package com.manzafio.eventos.network;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Servidor -> cliente: dispara un efecto (onda de calor, explosión, etc). */
public record FxPacket(byte type) {

    public void encode(FriendlyByteBuf buf) {
        buf.writeByte(type);
    }

    public static FxPacket decode(FriendlyByteBuf buf) {
        return new FxPacket(buf.readByte());
    }

    public static void handle(FxPacket msg, Supplier<NetworkEvent.Context> ctx) {
        DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () ->
                com.manzafio.eventos.client.ClientEventState.onFx(msg.type()));
    }
}
