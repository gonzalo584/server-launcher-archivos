package com.manzafio.eventos.network;

import com.manzafio.eventos.event.SolarEventManager;
import net.minecraft.ChatFormatting;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Cliente -> servidor: "inicia este evento con esta duración". */
public record StartEventPacket(String eventId, int seconds) {

    public void encode(FriendlyByteBuf buf) {
        buf.writeUtf(eventId, 64);
        buf.writeVarInt(seconds);
    }

    public static StartEventPacket decode(FriendlyByteBuf buf) {
        return new StartEventPacket(buf.readUtf(64), buf.readVarInt());
    }

    public static void handle(StartEventPacket msg, Supplier<NetworkEvent.Context> ctx) {
        ServerPlayer player = ctx.get().getSender();
        if (player == null) return;
        if (!player.hasPermissions(2)) {
            player.sendSystemMessage(Component.literal("Solo los moderadores pueden iniciar eventos.").withStyle(ChatFormatting.RED));
            return;
        }
        if (SolarEventManager.EVENT_ID.equals(msg.eventId())) {
            if (!SolarEventManager.start(player.server, msg.seconds(), player.getGameProfile().getName())) {
                player.sendSystemMessage(Component.literal("Ya hay un evento activo. Cancélalo primero.").withStyle(ChatFormatting.RED));
            }
        }
    }
}
