package com.manzafio.eventos.event;

import com.manzafio.eventos.registry.ModDamage;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;

import java.util.ArrayList;
import java.util.List;

/**
 * Radiación de calor: dura 1 minuto, quita corazones cada segundo (cada vez más)
 * y si sigues vivo cuando se acaba, te mata. La leche NO la cura.
 */
public class HeatRadiationEffect extends MobEffect {

    public HeatRadiationEffect() {
        super(MobEffectCategory.HARMFUL, 0xFF7A1A);
    }

    @Override
    public boolean isDurationEffectTick(int duration, int amplifier) {
        return duration % 20 == 0 || duration <= 1;
    }

    @Override
    public void applyEffectTick(LivingEntity entity, int amplifier) {
        if (entity.level().isClientSide) return;

        MobEffectInstance inst = entity.getEffect(this);
        int remaining = inst == null ? 0 : inst.getDuration();
        DamageSource src = ModDamage.source(entity.level(), ModDamage.HEAT_RADIATION);

        if (remaining <= 1) {
            entity.invulnerableTime = 0;
            entity.hurt(src, 10000.0F);
            return;
        }

        int elapsedSec = Math.max(0, (SolarEventManager.RADIATION_TICKS - remaining) / 20);
        float damage = 0.25F + elapsedSec * 0.012F; // 0.25 -> ~1 corazón por segundo al final
        entity.invulnerableTime = 0;
        entity.hurt(src, damage);
    }

    @Override
    public List<ItemStack> getCurativeItems() {
        return new ArrayList<>();
    }
}
