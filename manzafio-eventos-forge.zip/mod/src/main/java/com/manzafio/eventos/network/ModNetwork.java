package com.manzafio.eventos.network;

import com.manzafio.eventos.ManzafioEventos;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkDirection;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.network.simple.SimpleChannel;

public final class ModNetwork {
    private static final String VERSION = "1";
    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
            ManzafioEventos.id("main"), () -> VERSION, VERSION::equals, VERSION::equals);

    private static boolean registered = false;

    public static void register() {
        if (registered) return;
        registered = true;
        int id = 0;
        CHANNEL.messageBuilder(StartEventPacket.class, id++, NetworkDirection.PLAY_TO_SERVER)
                .encoder(StartEventPacket::encode).decoder(StartEventPacket::decode)
                .consumerMainThread(StartEventPacket::handle).add();
        CHANNEL.messageBuilder(CancelEventPacket.class, id++, NetworkDirection.PLAY_TO_SERVER)
                .encoder(CancelEventPacket::encode).decoder(CancelEventPacket::decode)
                .consumerMainThread(CancelEventPacket::handle).add();
        CHANNEL.messageBuilder(SyncEventPacket.class, id++, NetworkDirection.PLAY_TO_CLIENT)
                .encoder(SyncEventPacket::encode).decoder(SyncEventPacket::decode)
                .consumerMainThread(SyncEventPacket::handle).add();
        CHANNEL.messageBuilder(FxPacket.class, id++, NetworkDirection.PLAY_TO_CLIENT)
                .encoder(FxPacket::encode).decoder(FxPacket::decode)
                .consumerMainThread(FxPacket::handle).add();
    }

    public static void toServer(Object msg) {
        CHANNEL.sendToServer(msg);
    }

    public static void toAll(Object msg) {
        CHANNEL.send(PacketDistributor.ALL.noArg(), msg);
    }

    public static void toPlayer(ServerPlayer player, Object msg) {
        CHANNEL.send(PacketDistributor.PLAYER.with(() -> player), msg);
    }

    private ModNetwork() {}
}
