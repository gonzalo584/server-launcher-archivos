package com.manzafio.eventos.event;

/** Efectos visuales/sonoros que el servidor dispara en los clientes. */
public final class FxType {
    public static final byte START = 0;
    public static final byte HEAT_PULSE = 1;
    public static final byte EXPLOSION = 2;
    public static final byte CANCEL = 3;
    public static final byte RADIATION_HIT = 4;
    public static final byte ATMOSPHERE_CLEAR = 5;

    private FxType() {}
}
