package com.manzafio.eventos.client;

import com.manzafio.eventos.ManzafioEventos;
import com.manzafio.eventos.client.gui.ModeratorMenuScreen;
import com.manzafio.eventos.event.EventPhase;
import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.FogRenderer;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ClientPlayerNetworkEvent;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.client.event.ViewportEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = ManzafioEventos.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public final class ClientForgeEvents {

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();

        while (ClientModEvents.OPEN_MENU.consumeClick()) {
            if (mc.player == null || mc.screen != null) continue;
            if (mc.player.hasPermissions(2)) {
                mc.setScreen(new ModeratorMenuScreen());
            } else {
                mc.player.displayClientMessage(Component.literal("Solo los moderadores pueden abrir este panel.")
                        .withStyle(ChatFormatting.RED), true);
            }
        }

        if (mc.level == null) return;
        if (!mc.isPaused()) {
            ClientEventState.clientTick();
            ClientFx.tickAmbient();
        }
    }

    @SubscribeEvent
    public static void onLogout(ClientPlayerNetworkEvent.LoggingOut event) {
        ClientEventState.reset();
    }

    @SubscribeEvent
    public static void onRenderLevel(RenderLevelStageEvent event) {
        if (event.getStage() != RenderLevelStageEvent.Stage.AFTER_SKY) return;
        SkyRenderer.render(event.getPoseStack(), event.getPartialTick());
    }

    @SubscribeEvent
    public static void onFogColor(ViewportEvent.ComputeFogColor event) {
        if (!ClientEventState.inOverworld()) return;
        float pt = (float) event.getPartialTick();
        float tr = 0, tg = 0, tb = 0, amount = 0;
        EventPhase phase = ClientEventState.phase();
        if (phase == EventPhase.COUNTDOWN) {
            float p = ClientEventState.progress(pt);
            tr = 0.85F; tg = 0.22F; tb = 0.08F;
            amount = p * 0.75F;
        } else if (phase == EventPhase.AFTERMATH) {
            tr = 0.95F; tg = 0.72F; tb = 0.32F;
            amount = 0.8F;
        }
        if (amount > 0 && !ClientEventState.isPlayerSafe()) {
            event.setRed(Mth.lerp(amount, event.getRed(), tr));
            event.setGreen(Mth.lerp(amount, event.getGreen(), tg));
            event.setBlue(Mth.lerp(amount, event.getBlue(), tb));
        }
        if (ClientEventState.flashTicks > 0) {
            float f = Math.min(1F, ClientEventState.flashTicks / 60F);
            event.setRed(Mth.lerp(f, event.getRed(), 1F));
            event.setGreen(Mth.lerp(f, event.getGreen(), 1F));
            event.setBlue(Mth.lerp(f, event.getBlue(), 0.95F));
        }
    }

    @SubscribeEvent
    public static void onRenderFog(ViewportEvent.RenderFog event) {
        if (!ClientEventState.inOverworld()) return;
        if (event.getMode() != FogRenderer.FogMode.FOG_TERRAIN) return;
        if (ClientEventState.phase() != EventPhase.AFTERMATH || ClientEventState.isPlayerSafe()) return;
        // polvo radiactivo en el aire: niebla más cerrada
        float far = Math.min(event.getFarPlaneDistance(), 80F);
        event.setFarPlaneDistance(far);
        event.setNearPlaneDistance(far * 0.05F);
        event.setCanceled(true);
    }

    @SubscribeEvent
    public static void onCameraAngles(ViewportEvent.ComputeCameraAngles event) {
        if (ClientEventState.shakeTicks <= 0) return;
        float pt = (float) event.getPartialTick();
        float k = Math.max(0F, (ClientEventState.shakeTicks - pt) / (float) ClientEventState.shakeMax);
        float s = ClientEventState.shakeStrength * k * k;
        float t = ClientEventState.clientTicks + pt;
        event.setYaw(event.getYaw() + (Mth.sin(t * 1.9F) + Mth.sin(t * 3.7F) * 0.5F) * s * 0.35F);
        event.setPitch(event.getPitch() + (Mth.cos(t * 2.3F) + Mth.sin(t * 4.1F) * 0.5F) * s * 0.35F);
        event.setRoll(event.getRoll() + Mth.sin(t * 2.9F) * s * 0.5F);
    }

    private ClientForgeEvents() {}
}
