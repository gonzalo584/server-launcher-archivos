package com.manzafio.eventos.client;

import com.manzafio.eventos.event.EventPhase;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.block.Blocks;

/** Partículas del evento (solo cliente, no afectan bloques). */
public final class ClientFx {
    private static final BlockParticleOption YELLOW_DUST =
            new BlockParticleOption(ParticleTypes.FALLING_DUST, Blocks.YELLOW_CONCRETE_POWDER.defaultBlockState());
    private static final BlockParticleOption SAND_DUST =
            new BlockParticleOption(ParticleTypes.FALLING_DUST, Blocks.SAND.defaultBlockState());
    private static final BlockParticleOption ORANGE_DUST =
            new BlockParticleOption(ParticleTypes.FALLING_DUST, Blocks.ORANGE_CONCRETE_POWDER.defaultBlockState());

    private ClientFx() {}

    /** Onda de calor: llamaradas que bajan del cielo y una ola de brasas alrededor del jugador. */
    public static void spawnHeatWave(float progress) {
        Minecraft mc = Minecraft.getInstance();
        ClientLevel level = mc.level;
        LocalPlayer player = mc.player;
        if (level == null || player == null) return;
        RandomSource r = level.random;

        int count = 30 + (int) (progress * 90);
        for (int i = 0; i < count; i++) {
            double x = player.getX() + (r.nextDouble() - 0.5) * 28;
            double z = player.getZ() + (r.nextDouble() - 0.5) * 28;
            double y = player.getY() + 4 + r.nextDouble() * 10;
            if (!level.canSeeSky(BlockPos.containing(x, y, z))) continue;
            ParticleOptions type = r.nextFloat() < 0.6F ? ParticleTypes.FLAME : ParticleTypes.SMALL_FLAME;
            level.addParticle(type, x, y, z, (r.nextDouble() - 0.5) * 0.05, -0.15 - r.nextDouble() * 0.2, (r.nextDouble() - 0.5) * 0.05);
        }

        // Anillo de brasas que se expande desde el jugador
        int ring = 40 + (int) (progress * 40);
        for (int i = 0; i < ring; i++) {
            double a = i * Math.PI * 2 / ring;
            double sp = 0.35 + progress * 0.4;
            double x = player.getX() + Math.cos(a) * 1.5;
            double z = player.getZ() + Math.sin(a) * 1.5;
            double y = player.getY() + 0.2 + r.nextDouble() * 1.2;
            if (!level.canSeeSky(BlockPos.containing(x, y, z))) continue;
            level.addParticle(r.nextBoolean() ? ParticleTypes.LAVA : ParticleTypes.FLAME,
                    x, y, z, Math.cos(a) * sp, 0.02, Math.sin(a) * sp);
        }
    }

    /** Partículas continuas cada tick según la fase. */
    public static void tickAmbient() {
        Minecraft mc = Minecraft.getInstance();
        ClientLevel level = mc.level;
        LocalPlayer player = mc.player;
        if (level == null || player == null || mc.isPaused() || !ClientEventState.inOverworld()) return;
        RandomSource r = level.random;
        EventPhase phase = ClientEventState.phase();

        if (phase == EventPhase.COUNTDOWN) {
            float p = ClientEventState.progress(0);
            if (p < 0.25F) return;
            int n = (int) (p * p * 10);
            for (int i = 0; i < n; i++) {
                double x = player.getX() + (r.nextDouble() - 0.5) * 30;
                double z = player.getZ() + (r.nextDouble() - 0.5) * 30;
                double y = player.getY() + (r.nextDouble() - 0.3) * 12;
                if (!level.canSeeSky(BlockPos.containing(x, y, z))) continue;
                float pick = r.nextFloat();
                if (pick < 0.55F) {
                    level.addParticle(ParticleTypes.WHITE_ASH, x, y, z, 0, 0, 0);
                } else if (pick < 0.85F) {
                    level.addParticle(ParticleTypes.ASH, x, y, z, 0, 0, 0);
                } else if (p > 0.6F) {
                    level.addParticle(ParticleTypes.SMALL_FLAME, x, y, z, 0, 0.01, 0);
                }
            }
        } else if (phase == EventPhase.AFTERMATH) {
            // Polvo amarillo cayendo como radiación
            for (int i = 0; i < 28; i++) {
                double x = player.getX() + (r.nextDouble() - 0.5) * 34;
                double z = player.getZ() + (r.nextDouble() - 0.5) * 34;
                double y = player.getY() + 2 + r.nextDouble() * 16;
                if (!level.canSeeSky(BlockPos.containing(x, y, z))) continue;
                float pick = r.nextFloat();
                ParticleOptions type = pick < 0.55F ? YELLOW_DUST : pick < 0.85F ? SAND_DUST : ORANGE_DUST;
                level.addParticle(type, x, y, z, 0, 0, 0);
            }
            if (r.nextFloat() < 0.5F) {
                double x = player.getX() + (r.nextDouble() - 0.5) * 20;
                double z = player.getZ() + (r.nextDouble() - 0.5) * 20;
                double y = player.getY() + r.nextDouble() * 8;
                if (level.canSeeSky(BlockPos.containing(x, y, z))) {
                    level.addParticle(ParticleTypes.WHITE_ASH, x, y, z, 0, 0, 0);
                }
            }
            // Jugador irradiado: humo y chispas saliendo de él
            if (mc.player.hasEffect(com.manzafio.eventos.registry.ModEffects.HEAT_RADIATION.get()) && r.nextFloat() < 0.6F) {
                level.addParticle(ParticleTypes.SMOKE,
                        player.getX() + (r.nextDouble() - 0.5) * 0.8, player.getY() + r.nextDouble() * 1.8,
                        player.getZ() + (r.nextDouble() - 0.5) * 0.8, 0, 0.05, 0);
                if (r.nextFloat() < 0.3F) {
                    level.addParticle(ParticleTypes.FLAME,
                            player.getX() + (r.nextDouble() - 0.5) * 0.8, player.getY() + r.nextDouble() * 1.8,
                            player.getZ() + (r.nextDouble() - 0.5) * 0.8, 0, 0.03, 0);
                }
            }
        }

        // Explosión: lluvia de chispas los primeros segundos
        int age = ClientEventState.explosionAge;
        if (age >= 0 && age < 80) {
            int n = (int) Mth.lerp(age / 80F, 60, 5);
            for (int i = 0; i < n; i++) {
                double x = player.getX() + (r.nextDouble() - 0.5) * 40;
                double z = player.getZ() + (r.nextDouble() - 0.5) * 40;
                double y = player.getY() + 6 + r.nextDouble() * 18;
                if (!level.canSeeSky(BlockPos.containing(x, y, z))) continue;
                level.addParticle(r.nextBoolean() ? ParticleTypes.FLAME : ParticleTypes.LAVA,
                        x, y, z, (r.nextDouble() - 0.5) * 0.2, -0.3 - r.nextDouble() * 0.3, (r.nextDouble() - 0.5) * 0.2);
            }
        }
    }
}
