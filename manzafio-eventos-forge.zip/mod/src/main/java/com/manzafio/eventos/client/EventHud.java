package com.manzafio.eventos.client;

import com.manzafio.eventos.client.gui.UiDraw;
import com.manzafio.eventos.event.EventPhase;
import com.manzafio.eventos.event.SolarEventManager;
import com.manzafio.eventos.registry.ModEffects;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.util.Mth;
import net.minecraftforge.client.gui.overlay.ForgeGui;

/** HUD del evento: contador, avisos, viñetas y el flashbang. */
public final class EventHud {
    private EventHud() {}

    public static void render(ForgeGui gui, GuiGraphics g, float partialTick, int w, int h) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.options.hideGui && ClientEventState.flashTicks <= 0) return;
        if (!ClientEventState.inOverworld()) return;
        Font font = mc.font;
        float time = ClientEventState.clientTicks + partialTick;
        EventPhase phase = ClientEventState.phase();
        boolean safe = ClientEventState.isPlayerSafe();

        // ---------------- capas de color a pantalla completa
        if (phase == EventPhase.COUNTDOWN) {
            float p = ClientEventState.progress(partialTick);
            if (!safe) {
                // aire caliente
                g.fill(0, 0, w, h, UiDraw.withAlpha(0xFF4A10, p * 0.13F));
                UiDraw.vignette(g, w, h, 0xFF3000, p * 0.55F, (int) (h * 0.22F));
            }
            if (ClientEventState.pulseTicks > 0) {
                float k = (ClientEventState.pulseTicks - partialTick) / ClientEventState.PULSE_MAX;
                k = Math.max(0, k);
                float strength = (safe ? 0.25F : 0.75F) * k * (0.5F + p * 0.5F);
                // la onda llega desde los bordes hacia el centro
                int thick = (int) (h * (0.15F + (1F - k) * 0.35F));
                UiDraw.vignette(g, w, h, 0xFF6A00, strength, thick);
                g.fill(0, 0, w, h, UiDraw.withAlpha(0xFFB040, strength * 0.25F));
            }
        } else if (phase == EventPhase.AFTERMATH) {
            if (!safe) {
                g.fill(0, 0, w, h, UiDraw.withAlpha(0xFFC040, 0.16F));
                UiDraw.vignette(g, w, h, 0xE0A020, 0.5F, (int) (h * 0.25F));
            }
        }

        boolean irradiated = mc.player.hasEffect(ModEffects.HEAT_RADIATION.get());
        if (irradiated) {
            float beat = 0.5F + 0.5F * Mth.sin(time * 0.35F);
            UiDraw.vignette(g, w, h, 0xFF1A00, 0.45F + beat * 0.35F, (int) (h * 0.3F));
            g.fill(0, 0, w, h, UiDraw.withAlpha(0xFF2000, 0.08F + beat * 0.07F));
        }
        if (ClientEventState.radiationHitTicks > 0) {
            float k = ClientEventState.radiationHitTicks / 40F;
            g.fill(0, 0, w, h, UiDraw.withAlpha(0xFF3000, k * 0.5F));
        }
        if (ClientEventState.clearTicks > 0) {
            float k = ClientEventState.clearTicks / 80F;
            g.fill(0, 0, w, h, UiDraw.withAlpha(0x9AF0FF, k * 0.18F));
        }

        // ---------------- paneles de texto
        if (!mc.options.hideGui) {
            if (phase == EventPhase.COUNTDOWN) {
                drawCountdownPanel(g, font, w, h, partialTick, time, safe);
            } else if (phase == EventPhase.AFTERMATH) {
                drawAftermathPanel(g, font, w, h, time, safe, irradiated);
            }
            if (ClientEventState.clearTicks > 0) {
                float a = Math.min(1F, ClientEventState.clearTicks / 20F);
                UiDraw.scaledCentered(g, font, "✔ La atmósfera se estabilizó", w / 2, h / 3, 2F, UiDraw.withAlpha(0x7CFF9A, a));
            }
        }

        // ---------------- FLASHBANG (va encima de todo)
        if (ClientEventState.flashTicks > 0) {
            float f = ClientEventState.flashTicks - partialTick;
            float alpha = f > 50 ? 1F : Math.max(0F, f / 50F);
            int color = UiDraw.lerpColor(1F - Math.min(1F, f / ClientEventState.FLASH_TICKS * 1.3F), 0xFFFFFFFF, 0xFFFFF4D0);
            g.fill(0, 0, w, h, UiDraw.withAlpha(color & 0xFFFFFF, alpha));
        }
    }

    private static void drawCountdownPanel(GuiGraphics g, Font font, int w, int h, float pt, float time, boolean safe) {
        float p = ClientEventState.progress(pt);
        int left = ClientEventState.ticksLeft();
        int pw = 220, ph = 58;
        int x = w / 2 - pw / 2, y = 6;

        UiDraw.panel(g, x, y, pw, ph, 0xFF3A10, time);
        UiDraw.sun(g, x + 20, y + 22, 9, time * (1 + p * 3), p);

        g.drawString(font, "☀ EXPLOSIÓN SOLAR", x + 38, y + 7, 0xFFFF6A3A, true);
        String timeStr = SolarEventManager.formatTime(left);
        int timerColor = left < 200 && (ClientEventState.clientTicks / 5) % 2 == 0 ? 0xFFFFFFFF : 0xFFFFC040;
        g.pose().pushPose();
        g.pose().translate(x + 38, y + 18, 0);
        g.pose().scale(2F, 2F, 1F);
        g.drawString(font, timeStr, 0, 0, timerColor, true);
        g.pose().popPose();

        String layer = "Tu capa: Y " + Minecraft.getInstance().player.getBlockY();
        String goal = "Meta: Y " + SolarEventManager.SAFE_Y;
        g.drawString(font, goal, x + pw - 8 - font.width(goal), y + 8, 0xFFBBBBBB, true);
        int lc = safe ? 0xFF6CFF7A : ((ClientEventState.clientTicks / 10) % 2 == 0 ? 0xFFFF4040 : 0xFFFF9090);
        g.drawString(font, layer, x + pw - 8 - font.width(layer), y + 20, lc, true);
        String status = safe ? "✔ A salvo" : "⚠ ¡Baja!";
        g.drawString(font, status, x + pw - 8 - font.width(status), y + 31, lc, true);

        // barra de progreso
        int bx = x + 8, by = y + ph - 11, bw = pw - 16;
        g.fill(bx - 1, by - 1, bx + bw + 1, by + 6, 0xFF000000);
        g.fill(bx, by, bx + bw, by + 5, 0xFF2A1410);
        UiDraw.hGradient(g, bx, by, bx + (int) (bw * p), by + 5, 0xFFFFC23A, 0xFFE0200A);
        int sx = bx + (int) (bw * p);
        g.fill(sx - 1, by - 2, sx + 1, by + 7, 0xFFFFFFFF);

        // números gigantes en los últimos 10 segundos
        int sec = (left + 19) / 20;
        if (left > 0 && sec <= 10) {
            float frac = (left % 20) / 20F;
            float scale = 4F + frac * 3F;
            int col = UiDraw.withAlpha(sec <= 3 ? 0xFF2A10 : 0xFFB020, 0.35F + frac * 0.65F);
            UiDraw.scaledCentered(g, font, String.valueOf(sec), w / 2, (int) (h / 2 - 4 * scale), scale, col);
            if (!safe) {
                UiDraw.scaledCentered(g, font, "¡BAJA A Y " + SolarEventManager.SAFE_Y + "!", w / 2, h / 2 + 30, 1.5F, 0xFFFF5040);
            }
        }
    }

    private static void drawAftermathPanel(GuiGraphics g, Font font, int w, int h, float time, boolean safe, boolean irradiated) {
        int pw = 230, ph = 46;
        int x = w / 2 - pw / 2, y = 6;
        UiDraw.panel(g, x, y, pw, ph, 0xE0A020, time);

        // símbolo de radiación girando (aspa de 3 sectores)
        int cx = x + 20, cy = y + 23;
        UiDraw.circle(g, cx, cy, 11, 0xFFFFD02A);
        UiDraw.circle(g, cx, cy, 9, 0xFF201006);
        UiDraw.circle(g, cx, cy, 2, 0xFFFFD02A);
        for (int i = 0; i < 3; i++) {
            float a = time * 0.05F + i * (float) (Math.PI * 2 / 3);
            for (int s = 4; s <= 8; s++) {
                int px = cx + (int) (Mth.cos(a) * s), py = cy + (int) (Mth.sin(a) * s);
                g.fill(px - 2, py - 2, px + 2, py + 2, 0xFFFFD02A);
            }
        }

        g.drawString(font, "☢ RADIACIÓN SOLAR", x + 38, y + 7, 0xFFFFD02A, true);
        String sub = "No salgas arriba de Y " + SolarEventManager.SAFE_Y + "  ·  " + SolarEventManager.formatTime(ClientEventState.ticksLeft());
        g.drawString(font, sub, x + 38, y + 19, 0xFFFFE6A0, true);
        String st = irradiated ? "☠ ¡ESTÁS IRRADIADO!" : safe ? "✔ Estás a salvo" : "⚠ ¡ESTÁS EXPUESTO!";
        int col = irradiated || !safe ? ((ClientEventState.clientTicks / 8) % 2 == 0 ? 0xFFFF3A2A : 0xFFFFA090) : 0xFF6CFF7A;
        g.drawString(font, st, x + 38, y + 31, col, true);

        float p = 1F - ClientEventState.ticksLeft() / (float) Math.max(1, ClientEventState.totalTicks());
        g.fill(x + 8, y + ph - 3, x + pw - 8, y + ph - 2, 0xFF3A2A10);
        g.fill(x + 8, y + ph - 3, x + 8 + (int) ((pw - 16) * p), y + ph - 2, 0xFFFFD02A);
    }
}
