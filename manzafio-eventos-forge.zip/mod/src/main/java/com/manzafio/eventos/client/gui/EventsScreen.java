package com.manzafio.eventos.client.gui;

import com.manzafio.eventos.client.ClientEventState;
import com.manzafio.eventos.event.EventPhase;
import com.manzafio.eventos.event.SolarEventManager;
import com.manzafio.eventos.network.CancelEventPacket;
import com.manzafio.eventos.network.ModNetwork;
import com.manzafio.eventos.network.StartEventPacket;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;

/**
 * Lista de eventos estilo Dedsafio. Por ahora: Explosión Solar.
 * Para agregar más eventos se añade otra "tarjeta" aquí y otro manager en el servidor.
 */
public class EventsScreen extends Screen {
    private static final int W = 330, H = 236;
    private static int durationSeconds = 5 * 60; // se recuerda entre aperturas

    private final Screen parent;
    private final long openedAt = System.currentTimeMillis();
    private int left, top;
    private FancyButton startBtn, cancelBtn;

    public EventsScreen(Screen parent) {
        super(Component.literal("Eventos"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        left = (this.width - W) / 2;
        top = (this.height - H) / 2;

        int cardX = left + 12, cardY = top + 46;

        // Selector de tiempo
        int rowY = cardY + 92;
        addRenderableWidget(new FancyButton(cardX + 62, rowY, 20, 18, Component.literal("-"), 0xFF4A3A3A, () -> changeDuration(-1)));
        addRenderableWidget(new FancyButton(cardX + 138, rowY, 20, 18, Component.literal("+"), 0xFF4A3A3A, () -> changeDuration(1)));
        int[] presets = {1, 3, 5, 10};
        for (int i = 0; i < presets.length; i++) {
            int min = presets[i];
            addRenderableWidget(new FancyButton(cardX + 168 + i * 34, rowY, 31, 18,
                    Component.literal(min + " m"), 0xFF6A3A1A, () -> durationSeconds = min * 60));
        }

        int by = top + H - 32;
        startBtn = addRenderableWidget(new FancyButton(left + 12, by, 130, 22,
                Component.literal("▶  INICIAR EVENTO"), 0xFFE0661A, this::startEvent));
        cancelBtn = addRenderableWidget(new FancyButton(left + 148, by, 100, 22,
                Component.literal("■  CANCELAR"), 0xFFB0202A, () -> ModNetwork.toServer(new CancelEventPacket())));
        addRenderableWidget(new FancyButton(left + 254, by, 64, 22,
                Component.literal("← VOLVER"), 0xFF3A3A48, this::onClose));
        refreshButtons();
    }

    private void changeDuration(int dir) {
        int step = (durationSeconds < 120 || (dir < 0 && durationSeconds <= 120)) ? 30 : 60;
        if (durationSeconds <= 30 && dir < 0) step = 10;
        if (durationSeconds < 30 && dir > 0) step = 10;
        durationSeconds = Mth.clamp(durationSeconds + dir * step, SolarEventManager.MIN_SECONDS, SolarEventManager.MAX_SECONDS);
    }

    private void startEvent() {
        ModNetwork.toServer(new StartEventPacket(SolarEventManager.EVENT_ID, durationSeconds));
        this.minecraft.setScreen(null);
    }

    private void refreshButtons() {
        boolean active = ClientEventState.phase() != EventPhase.NONE;
        if (startBtn != null) startBtn.active = !active;
        if (cancelBtn != null) cancelBtn.active = active;
    }

    @Override
    public void tick() {
        super.tick();
        refreshButtons();
    }

    @Override
    public void onClose() {
        this.minecraft.setScreen(parent);
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        float time = ClientEventState.clientTicks + partialTick;
        float open = Math.min(1F, (System.currentTimeMillis() - openedAt) / 220F);
        float ease = 1F - (1F - open) * (1F - open);

        this.renderBackground(g);
        g.fillGradient(0, 0, this.width, this.height, 0x60200808, 0xA0000000);

        g.pose().pushPose();
        g.pose().translate(0, (1F - ease) * 18F, 0);

        UiDraw.panel(g, left, top, W, H, 0xFF5A1A, time);
        UiDraw.hGradient(g, left + 1, top + 1, left + W - 1, top + 36, 0xC0FF5A1A, 0x10FFC23A);
        UiDraw.scaledCentered(g, this.font, "EVENTOS", left + W / 2, top + 9, 2F, 0xFFFFFFFF);
        g.drawCenteredString(this.font, "Elige un evento para todo el servidor", left + W / 2, top + 28, 0xFFFFD9B0);

        // ------------------------------------------------ tarjeta: Explosión Solar
        int cx = left + 12, cy = top + 46, cw = W - 24, ch = 118;
        boolean running = ClientEventState.phase() != EventPhase.NONE;
        float heat = running ? ClientEventState.progress(partialTick) : 0.5F + 0.5F * Mth.sin(time * 0.03F);

        g.fill(cx - 1, cy - 1, cx + cw + 1, cy + ch + 1, UiDraw.withAlpha(0xFF6A2A, 0.8F));
        g.fillGradient(cx, cy, cx + cw, cy + ch, 0xFF2A120C, 0xFF140806);
        // franja lateral animada
        UiDraw.hGradient(g, cx, cy, cx + 70, cy + 84, UiDraw.withAlpha(0xFF4A10, 0.35F + 0.15F * Mth.sin(time * 0.1F)), 0x00FF4A10);
        UiDraw.sun(g, cx + 34, cy + 38, 17, time * (1F + heat * 2F), heat);
        // rayos alrededor del icono
        for (int i = 0; i < 10; i++) {
            float a = time * 0.02F + i * (float) (Math.PI * 2 / 10);
            int rx = cx + 34 + (int) (Mth.cos(a) * 27), ry = cy + 38 + (int) (Mth.sin(a) * 27);
            g.fill(rx - 1, ry - 1, rx + 2, ry + 2, UiDraw.withAlpha(0xFFB040, 0.7F));
        }

        int tx = cx + 74;
        UiDraw.scaledCentered(g, this.font, "EXPLOSIÓN SOLAR", tx + 60, cy + 8, 1.5F, 0xFFFF7A3A);
        String tag = running ? "EN CURSO" : "LISTO";
        int tagColor = running ? 0xFFE02A2A : 0xFF2AA04A;
        int tagW = this.font.width(tag) + 8;
        g.fill(cx + cw - tagW - 6, cy + 7, cx + cw - 6, cy + 19, tagColor);
        g.drawString(this.font, tag, cx + cw - tagW - 2, cy + 9, 0xFFFFFFFF, false);

        int ly = cy + 26;
        String[] lines = {
                "El cielo se pone rojo y el sol",
                "lanza ondas de calor hasta EXPLOTAR.",
                "§eBajen a Y " + SolarEventManager.SAFE_Y + "§r antes del tiempo.",
                "Luego §63 min de radiación§r: si salen,",
                "se queman 1 min hasta morir."
        };
        for (String line : lines) {
            g.drawString(this.font, line, tx, ly, 0xFFE6D2C0, false);
            ly += 10;
        }

        // fila de tiempo
        int rowY = cy + 92;
        g.drawString(this.font, "Tiempo:", cx + 10, rowY + 5, 0xFFFFD9B0, true);
        g.fill(cx + 84, rowY, cx + 136, rowY + 18, 0xFF000000);
        g.fill(cx + 85, rowY + 1, cx + 135, rowY + 17, 0xFF2A1A12);
        g.drawCenteredString(this.font, SolarEventManager.formatTime(durationSeconds * 20), cx + 110, rowY + 5, 0xFFFFC040);

        // estado / ayuda
        String info;
        if (ClientEventState.phase() == EventPhase.COUNTDOWN) {
            info = "Explota en " + SolarEventManager.formatTime(ClientEventState.ticksLeft());
        } else if (ClientEventState.phase() == EventPhase.AFTERMATH) {
            info = "Radiación: termina en " + SolarEventManager.formatTime(ClientEventState.ticksLeft());
        } else {
            info = "Comandos: /manzafio explosionsolar <min> | cancelar";
        }
        g.drawCenteredString(this.font, info, left + W / 2, top + H - 46, running ? 0xFFFF9A5A : 0xFF7A7A7A);

        super.render(g, mouseX, mouseY, partialTick);
        g.pose().popPose();
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
