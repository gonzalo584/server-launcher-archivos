# Manzafio Eventos (Forge 1.20.1)

Panel de moderadores con la tecla **H** → botón **EVENTOS** → **Explosión Solar**.

## Cómo sacar el .jar (sin instalar nada)
1. Crea un repo nuevo en GitHub (por ejemplo `manzafio-eventos`).
2. Sube TODO el contenido de esta carpeta (incluida la carpeta `.github`).
3. Ve a la pestaña **Actions** → espera a que "Compilar mod" salga en verde (5-10 min la primera vez).
4. Abre esa ejecución → abajo en **Artifacts** descarga `manzafio-eventos-jar`.
5. Adentro viene `manzafioeventos-1.0.0.jar`. Ese va en la carpeta `mods`.

## Cómo compilar en tu PC (opcional)
Necesitas Java 17. En esta carpeta: `gradlew build` (Windows) o `./gradlew build`.
El jar sale en `build/libs/`.

## Instalación
- Ponlo en `mods` del **servidor (Exaroton)** y de **todos los jugadores** (lleva sonidos, pantallas y efectos del cielo).
- Quita el mod viejo `creative-event-console` (era de Fabric, no funciona en Forge).
- Solo los **OP (nivel 2+)** pueden abrir el panel e iniciar/cancelar eventos.

## Evento: Explosión Solar
- Eliges el tiempo (botones − / + o 1m, 3m, 5m, 10m) y le das a **INICIAR**.
- Se pone mediodía, suena una alarma, el sol crece y palpita y el cielo se pone cada vez más rojo.
- El sol lanza ondas de calor (temblor, llamaradas, viñeta naranja) cada vez más seguido.
- Últimos 10 s: números gigantes en pantalla y pitidos.
- Al acabar el tiempo: **explota el sol** → flashbang de 10 s, pitido en los oídos, temblor fuerte, onda expansiva en el cielo.
- Quien esté arriba de **Y -10** muere calcinado. No se rompe ningún bloque.
- Después: 3 min de cielo rojo-amarillento, niebla y polvo amarillo cayendo.
  Si sales arriba de Y -10 te da **Radiación de calor** 1 min: te quita corazones cada vez más y al final te mata (la leche no la cura).
- A los 3 min todo vuelve a la normalidad.
- **CANCELAR** detiene todo al instante y quita la radiación.

Comandos de respaldo: `/manzafio explosionsolar <minutos>` y `/manzafio cancelar`.

Para cambiar la capa segura edita `SAFE_Y` en `SolarEventManager.java`.
